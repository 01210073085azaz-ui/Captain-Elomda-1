package com.captain.teams

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

private data class Player(val name: String, val rating: Int)

class MainActivity : Activity() {
    private val players = mutableListOf<Player>()
    private var teams: List<List<Player>>? = null
    private lateinit var listBox: LinearLayout
    private lateinit var resultBox: LinearLayout
    private lateinit var raffleBox: LinearLayout
    private var matchA: Int? = null
    private var matchB: Int? = null
    private var waitingTeam: Int? = null
    private lateinit var countText: TextView
    private lateinit var nameInput: EditText
    private lateinit var ratingSpinner: Spinner
    private val green = Color.rgb(16, 61, 42)
    private val accent = Color.rgb(22, 131, 74)
    private val prefs by lazy { getSharedPreferences("captain_data", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadPlayers()
        buildScreen()
        refreshPlayers()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 249, 247))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(green)
        }
        val brandRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        brandRow.addView(text("⚽ CAPTAIN", 27f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        val stamp = TextView(this).apply {
            text = "Elomda"
            textSize = 17f
            typeface = Typeface.create("serif", Typeface.BOLD_ITALIC)
            setTextColor(Color.rgb(255, 225, 215))
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
            rotation = -8f
            letterSpacing = 0.04f
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), Color.rgb(235, 105, 82))
                cornerRadius = dp(5).toFloat()
            }
        }
        brandRow.addView(stamp)
        header.addView(brandRow)
        header.addView(text("قسّم فريقك بسهولة", 19f, Color.WHITE, true).apply { setPadding(0, dp(8), 0, 0) })
        header.addView(text("15 لاعب • 3 فرق • 5 لاعبين لكل فريق", 14f, Color.rgb(210, 230, 218), false).apply { setPadding(0, dp(5), 0, 0) })
        countText = text("اللاعبون: ${players.size}/15", 15f, Color.WHITE, true).apply { setPadding(0, dp(14), 0, 0) }
        header.addView(countText)
        root.addView(header)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        content.addView(sectionTitle("إضافة لاعب جديد"))
        nameInput = EditText(this).apply {
            hint = "اكتب اسم اللاعب"
            textSize = 16f
            singleLine = true
            setPadding(dp(12), 0, dp(12), 0)
            layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) }
        }
        content.addView(nameInput)
        ratingSpinner = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, listOf("1 - مبتدئ", "2 - أقل من المتوسط", "3 - متوسط", "4 - جيد جدًا", "5 - ممتاز"))
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        ratingSpinner.adapter = adapter
        content.addView(ratingSpinner)
        val add = button("＋ إضافة اللاعب", accent)
        add.setOnClickListener { addPlayer() }
        content.addView(add, matchWrap())
        content.addView(sectionTitle("قائمة اللاعبين").apply { setPadding(0, dp(22), 0, dp(8)) })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listBox)
        val divide = button("⚽ تقسيم الفرق الآن", green).apply {
            textSize = 17f
            setOnClickListener { divideTeams() }
        }
        content.addView(divide, matchWrap())
        val again = button("⟳ إعادة التقسيم", accent).apply { setOnClickListener { divideTeams() } }
        content.addView(again, matchWrap())
        val clear = button("مسح كل اللاعبين", Color.DKGRAY).apply {
            setOnClickListener {
                players.clear(); teams = null; resetMatch(); savePlayers(); refreshPlayers(); resultBox.removeAllViews(); raffleBox.removeAllViews()
            }
        }
        content.addView(clear, matchWrap())
        resultBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), 0, 0) }
        content.addView(resultBox)
        raffleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, 0) }
        content.addView(raffleBox)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun addPlayer() {
        val n = nameInput.text.toString().trim()
        if (n.isEmpty()) { toast("اكتب اسم اللاعب الأول"); return }
        if (players.size >= 15) { toast("وصلت للعدد المطلوب: 15 لاعب"); return }
        players.add(Player(n, ratingSpinner.selectedItemPosition + 1))
        nameInput.text.clear(); teams = null; resetMatch(); savePlayers(); refreshPlayers(); resultBox.removeAllViews(); raffleBox.removeAllViews()
    }

    private fun refreshPlayers() {
        countText.text = "اللاعبون: ${players.size}/15"
        listBox.removeAllViews()
        if (players.isEmpty()) {
            listBox.addView(text("لسه مفيش لاعبين. ابدأ بإضافة الأسماء.", 14f, Color.GRAY, false).apply { setPadding(0, dp(8), 0, dp(8)) })
        }
        players.forEachIndexed { index, p ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(8), dp(4), dp(8)) }
            val label = text("${index + 1}. ${p.name}   •   ${p.rating} ⭐", 15f, Color.rgb(35, 50, 42), false)
            row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
            val del = TextView(this).apply {
                text = "حذف"; textSize = 13f; setTextColor(Color.rgb(180, 45, 45)); gravity = Gravity.CENTER
                setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { players.removeAt(index); teams = null; resetMatch(); savePlayers(); refreshPlayers(); resultBox.removeAllViews(); raffleBox.removeAllViews() }
            }
            row.addView(del)
            listBox.addView(row)
            val line = View(this).apply { setBackgroundColor(Color.rgb(225, 232, 227)) }
            listBox.addView(line, LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    // Exhaustively checks all unique 5/5/5 partitions and chooses the smallest rating spread.
    private fun divideTeams() {
        if (players.size != 15) { toast("لازم تضيف 15 لاعب بالضبط"); return }
        val p = players.toList()
        val total = p.sumOf { it.rating }
        val target = total / 3.0
        var bestScore = Double.POSITIVE_INFINITY
        var best: List<List<Player>>? = null
        val teamA = mutableListOf<Int>()
        val teamB = mutableListOf<Int>()
        val teamC = mutableListOf<Int>()
        fun evaluate() {
            val sums = listOf(teamA, teamB, teamC).map { group -> group.sumOf { p[it].rating }.toDouble() }
            val mean = sums.average()
            val score = sums.sumOf { (it - mean) * (it - mean) }
            if (score < bestScore - 1e-9) {
                bestScore = score
                best = listOf(teamA, teamB, teamC).map { group -> group.map { p[it] } }
            }
        }
        // Keep player 0 in A to avoid equivalent permutations of team labels.
        teamA.add(0)
        fun chooseA(start: Int) {
            if (teamA.size == 5) { chooseB(1); return }
            for (i in start until 15) {
                if (i == 0) continue
                teamA.add(i); chooseA(i + 1); teamA.removeAt(teamA.lastIndex)
            }
        }
        fun chooseB(start: Int) {
            if (teamB.size == 5) {
                teamC.clear()
                for (i in 0 until 15) if (i !in teamA && i !in teamB) teamC.add(i)
                if (teamC.size == 5) evaluate()
                return
            }
            for (i in start until 15) {
                if (i in teamA) continue
                teamB.add(i); chooseB(i + 1); teamB.removeAt(teamB.lastIndex)
            }
        }
        chooseA(1)
        teams = best
        resetMatch()
        raffleBox.removeAllViews()
        showTeams(best!!, target)
    }

    private fun showTeams(groups: List<List<Player>>, target: Double) {
        resultBox.removeAllViews()
        resultBox.addView(sectionTitle("نتيجة التقسيم ⚽"))
        val colors = listOf(Color.rgb(22, 131, 74), Color.rgb(35, 104, 176), Color.rgb(190, 125, 25))
        groups.forEachIndexed { index, group ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
                setBackgroundColor(Color.WHITE)
            }
            val sum = group.sumOf { it.rating }
            card.addView(text("${listOf("الفريق الأول 🟢", "الفريق الثاني 🔵", "الفريق الثالث 🟠")[index]}     المجموع: $sum نقطة", 17f, colors[index], true))
            group.forEachIndexed { i, player -> card.addView(text("${i + 1}. ${player.name}     ${player.rating} ⭐", 15f, Color.DKGRAY, false).apply { setPadding(0, dp(7), 0, 0) }) }
            val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
            resultBox.addView(card, lp)
        }
        val sums = groups.map { it.sumOf { player -> player.rating } }
        resultBox.addView(text("الفارق بين أعلى وأقل فريق: ${sums.maxOrNull()!! - sums.minOrNull()!!} نقطة", 14f, green, true).apply { setPadding(0, dp(4), 0, dp(8)) })
        resultBox.addView(text("تم اختيار أفضل تقسيم ممكن حسب مجموع التقييمات.", 12f, Color.GRAY, false))
        val draw = button("🎲 قرعة أول مباراة", accent).apply { setOnClickListener { drawOpeningMatch() } }
        resultBox.addView(draw, matchWrap())
    }

    private fun resetMatch() {
        matchA = null
        matchB = null
        waitingTeam = null
    }

    private fun drawOpeningMatch() {
        val groups = teams ?: return
        val picked = (0..2).shuffled().take(2)
        matchA = picked[0]
        matchB = picked[1]
        waitingTeam = (0..2).first { it !in picked }
        showMatchState("القرعة الأولى", "تم اختيار أول فريقين عشوائيًا")
    }

    private fun showMatchState(title: String, subtitle: String) {
        val a = matchA ?: return
        val b = matchB ?: return
        val waiting = waitingTeam ?: return
        val names = listOf("الفريق الأول 🟢", "الفريق الثاني 🔵", "الفريق الثالث 🟠")
        raffleBox.removeAllViews()
        raffleBox.addView(sectionTitle("🎲 $title"))
        raffleBox.addView(text(subtitle, 13f, Color.GRAY, false).apply { setPadding(0, 0, 0, dp(8)) })
        val matchCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(12).toFloat(); setStroke(dp(1), Color.rgb(220, 230, 223)) }
        }
        matchCard.addView(text("⚽ ${names[a]}", 18f, Color.rgb(22, 131, 74), true).apply { gravity = Gravity.CENTER })
        matchCard.addView(text("ضــــد", 14f, Color.GRAY, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(5), 0, dp(5)) })
        matchCard.addView(text("⚽ ${names[b]}", 18f, Color.rgb(35, 104, 176), true).apply { gravity = Gravity.CENTER })
        matchCard.addView(text("⏳ ${names[waiting]} مستني", 15f, Color.rgb(160, 105, 20), true).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) })
        raffleBox.addView(matchCard, matchWrap())
        raffleBox.addView(sectionTitle("مين كسب المباراة؟").apply { setPadding(0, dp(14), 0, dp(5)) })
        val winA = button("🏆 ${names[a]} فاز", accent).apply { setOnClickListener { recordWinner(a) } }
        raffleBox.addView(winA, matchWrap())
        val winB = button("🏆 ${names[b]} فاز", Color.rgb(35, 104, 176)).apply { setOnClickListener { recordWinner(b) } }
        raffleBox.addView(winB, matchWrap())
        val newDraw = button("🎲 قرعة جديدة", Color.DKGRAY).apply { setOnClickListener { drawOpeningMatch() } }
        raffleBox.addView(newDraw, matchWrap())
    }

    private fun recordWinner(winner: Int) {
        val a = matchA ?: return
        val b = matchB ?: return
        val waiting = waitingTeam ?: return
        val loser = if (winner == a) b else a
        // Winner stays on; the waiting team enters, and the loser waits.
        matchA = winner
        matchB = waiting
        waitingTeam = loser
        val names = listOf("الفريق الأول", "الفريق الثاني", "الفريق الثالث")
        showMatchState("المباراة التالية – الفائز مستمر 🔥", "${names[winner]} كسب ومستمر، و${names[waiting]} يدخل الملعب")
    }

    private fun savePlayers() {
        val arr = JSONArray()
        players.forEach { arr.put(JSONObject().put("name", it.name).put("rating", it.rating)) }
        prefs.edit().putString("players", arr.toString()).apply()
    }
    private fun loadPlayers() {
        val raw = prefs.getString("players", null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                players.add(Player(obj.getString("name"), obj.getInt("rating").coerceIn(1, 5)))
            }
        } catch (_: Exception) { players.clear() }
    }

    private fun sectionTitle(s: String) = text(s, 18f, green, true).apply { setPadding(0, dp(4), 0, dp(10)) }
    private fun text(s: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
    }
    private fun button(s: String, color: Int) = Button(this).apply {
        text = s; setTextColor(Color.WHITE); textSize = 15f; isAllCaps = false
        setBackgroundColor(color); setPadding(dp(10), dp(5), dp(10), dp(5))
    }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(9) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
